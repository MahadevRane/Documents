/**
 * 
 */
package com.nucsoft.web.reactive.spring.services;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.async.DeferredResult;

import com.nucsoft.web.reactive.spring.cache.ConstantsCache;
import com.nucsoft.web.reactive.spring.cache.ServiceDetailsCacheService;
import com.nucsoft.web.reactive.spring.constant.Constants;
import com.nucsoft.web.reactive.spring.executors.DefaultThreadPoolExecutor;
import com.nucsoft.web.reactive.spring.executors.IServiceExecutor;
import com.nucsoft.web.reactive.spring.json.utils.JsonUtils;
import com.nucsoft.web.reactive.spring.processor.RequestFactoryInitializer;
import com.nucsoft.web.reactive.spring.serviceRepository.ServiceRepository;

/**
 * @author Satish Belose
 *
 */
@Service
public class WebClientPostService {

	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private ApplicationContext context;
	
	
	@Autowired
	private ServiceRepository serviceRepository;
	
	@Autowired
	public DefaultThreadPoolExecutor defaultThreadpool;
	
	@Autowired
	private ServiceDetailsCacheService cacheService;
	
	@Autowired
	private ConstantsCache cache;
	
	public DeferredResult<Object> requestProcessor(String requestBody,HttpServletRequest request,String pathVariable){
		long start_time = System.currentTimeMillis();	
		final DeferredResult<Object> deferredResult = new DeferredResult<Object>(Constants.DEFERRED_RESULT_TIMEOUT);
		
		IServiceExecutor<?> executor = new IServiceExecutor<Object>() {
						@Override
			public Object call() throws Exception {
				// TODO Auto-generated method stub
				JSONObject responseJson = new JSONObject();;
				String Query = "";
				String userName = "";
				String clientId = "";
				long end_time = 0;
				try {
										
					Map<String,Map<String,String>> constantMap = (Map<String, Map<String, String>>) cacheService.getData(cache);				
					Map<String,String> map = constantMap.get(pathVariable);
					String url = map.get(Constants.SERVICE_SOURCE_URL);
					int readTimeout = Integer.valueOf(map.get(Constants.READ_TIMEOUT));
					int connectionTimeout = Integer.valueOf(map.get(Constants.CONNECTION_TIMEOUT));
					String headersData = map.get(Constants.TARGET_HEADERS);
					//Query = map.get(Constants.QUERY);
					
					logger.info("url is--->"+url);
					logger.info("Read timeout is--->"+readTimeout);
					logger.info("Connection timeout is--->"+connectionTimeout);
					logger.info("Headers data is--->"+headersData);
					logger.info("Query--->"+Query);
					
					userName = request.getHeader(Constants.USERNAME);
					clientId = request.getHeader(Constants.AUTHORIZATION_HEADER);
					
					SimpleClientHttpRequestFactory factory = ((RequestFactoryInitializer)context.getBean(Constants.FACTORY_NAME)).getFactory();
					factory.setConnectTimeout(connectionTimeout);
					factory.setReadTimeout(readTimeout);					
					HttpEntity<String> requestEntity = new HttpEntity<String>(requestBody,prepareHeaderMap(headersData));					
					RestTemplate restTemplate = new RestTemplate(factory);
					org.springframework.http.ResponseEntity<String> data = restTemplate.postForEntity(URI.create(url), requestEntity, String.class);
					logger.info("Response Body is--->"+ data.getBody());
					
					//end_time = System.currentTimeMillis();
					logger.info("Time taken to service call is --->"+(end_time-start_time));
					JSONObject responseBody = new JSONObject(data.getBody());	
					responseJson.put("status","Success");
					responseJson.put("statusCode",101);
					responseJson.put("message","Request Completed Successfully.");
					responseJson.put("dataResponse",responseBody);
					
				}catch(Exception e) {
					logger.error("Error caused by--->",e);
					
					responseJson.put("status","Failure");
					responseJson.put("statusCode",102);
					responseJson.put("message","Request Completed Successfully.");
					responseJson.put("dataResponse",e.getMessage());
				}finally {
					end_time = System.currentTimeMillis();
					Map<String, Object> insertRecordsMap = new HashMap<>();
					insertRecordsMap.put("requestdata", requestBody);
					insertRecordsMap.put("responsedata", ""+responseJson);
					insertRecordsMap.put("updatedtime", end_time);
					insertRecordsMap.put("createdtime", start_time);
					insertRecordsMap.put("username",userName);
					insertRecordsMap.put("clientid",clientId);	
					insertRecordsMap.put("servicetype",pathVariable);
					serviceRepository.insertRecords(insertRecordsMap);
					logger.info(responseJson);
					deferredResult.setResult(responseJson.toString());
				}
				return deferredResult;
			}

			@Override
			public boolean getParentsStatuses() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public String getName() {
				// TODO Auto-generated method stub
				return WebClientPostService.class.getName();
			}
		};
		((DefaultThreadPoolExecutor)this.context.getBean(Constants.REQUEST_ACCEPTOR_TPE)).addTaskToQueue(executor);		
		return deferredResult;
	}	
	
	/**
	 * <p>
	 *    Given the string of headers, prepare header map
	 * </p>
	 * @param headers
	 * @return
	 */
	public static MultiValueMap<String, String> prepareHeaderMap(String headers)
	{   
		Map<String,Object> headerJsonMap = JsonUtils.prepareMapFromJson(headers);
		MultiValueMap<String, String> headerMap = new HttpHeaders();
		Map< String,String> hm = new HashMap< String,String>(); 
		headerJsonMap.entrySet().forEach((t)->hm.put(t.getKey(),t.getValue().toString()));
		headerMap.setAll(hm);
		return headerMap;
	}
	
}
