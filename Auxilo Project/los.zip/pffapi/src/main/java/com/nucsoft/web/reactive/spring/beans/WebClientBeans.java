package com.nucsoft.web.reactive.spring.beans;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.zaxxer.hikari.HikariDataSource;

@Configuration //Spring Configuration annotation indicates that the class has @Bean definition methods
public class WebClientBeans {

	private Logger logger = Logger.getLogger(WebClientBeans.class);
	
	/*
	 * Here we are creating bean of web client builder.
	*/
	@Bean("webClientBean")
	public WebClient webClientBuilder(WebClient.Builder builder){
		return builder.build();
	}	
	
	@Bean
    @Primary //we use @Primary to give higher preference to a bean when there are multiple beans of the same type.
    @ConfigurationProperties("spring.datasource") //@Bean method in a @Configuration class if you want to bind and validate some external Properties (e.g. from a .properties file). 
    public DataSourceProperties dataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "pgDatasource")
    @ConfigurationProperties("spring.datasource")
    public HikariDataSource dataSource(DataSourceProperties properties) {// HikariDataSource Default constructor.  Setters are used to configure the pool
        return properties.initializeDataSourceBuilder().type(HikariDataSource.class)
                .build();
    }
    
    @Bean(name = "pgJdbcTemplate")
	public JdbcTemplate jdbcTemplate1(@Qualifier("pgDatasource") DataSource ds) { //pgJdbcTemplate Construct a new JdbcTemplate, given a DataSource to obtain connections from.
		return new JdbcTemplate(ds);
	}
}
