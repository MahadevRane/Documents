/**
 * 
 */
package com.nucsoft.web.reactive.spring.serviceRepository;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * @author Satish Belose
 *
 */
@Component
public class ServiceRepository {

	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	@Qualifier("pgJdbcTemplate1")
	private JdbcTemplate jdbcTemplate1;

	@Autowired
	@Qualifier("pgJdbcTemplate2")
	private JdbcTemplate jdbcTemplate2;

	@Value("${apiname}")
	private String apiname;

	public Map<String, Map<String, String>> fetchConstantMap() {
		long start_time = System.currentTimeMillis();
		String Query = "select * from " + apiname + "_constants";
		logger.info("Query---->" + Query);
		Map<String, Map<String, String>> constantsMap = new HashMap<>();
		List<Map<String, Object>> list = jdbcTemplate1.queryForList(Query);
		for (int i = 0; i < list.size(); i++) {
			Map<String, Object> map = list.get(i);
			String entityType = (String) map.get("servicetype");
			if (!"".equals(entityType) && !constantsMap.containsKey(entityType)) {
				Map<String, String> temp = new HashMap<String, String>();
				temp.put((String) map.get("key"), (String) map.get("value"));
				constantsMap.put(entityType, temp);
			} else {
				constantsMap.get(entityType).put((String) map.get("key"), (String) map.get("value"));
			}
		}
		long end_time = System.currentTimeMillis();
		logger.info("Time taken to fetch the constant values from database is --->" + (end_time - start_time));
		return constantsMap;
	}

	public int insertRecords(Map<String, Object> insertRecordsMap) {
		long start_time = System.currentTimeMillis();
		int rowinserted = 0;
		String Query = "insert into "+ apiname +"_servicelog (requestdata,responsedata,updatedtime,createdtime,username,clientid,servicetype) values(?,?,?,?,?,?,?)";
		logger.info(insertRecordsMap);
		try {
			Object[] params = new Object[] { insertRecordsMap.get("requestdata"), insertRecordsMap.get("responsedata"),
					insertRecordsMap.get("updatedtime"), insertRecordsMap.get("createdtime"),
					insertRecordsMap.get("username"), insertRecordsMap.get("clientid"),
					insertRecordsMap.get("servicetype") };
			rowinserted = jdbcTemplate1.update(Query, params);
			logger.info(rowinserted + " Row inserted Successfully");
			long end_time = System.currentTimeMillis();
			logger.info("Time taken to insert the record in database is --->" + (end_time - start_time));
		} catch (Exception e) {
			logger.error("Error while inserting records into database caused by--->", e);
		}
		return rowinserted;
	}

	
	
	/*
	 * public int insertLOSRecords(Map<String, Object> insertRecordsMap) { long
	 * start_time = System.currentTimeMillis(); int rowinserted = 0; String Query =
	 * "insert into test1 (id,firstname,lastname,cdate) values(?,?,?,?)";
	 * logger.info(insertRecordsMap); try { Object[] params = new Object[] {
	 * insertRecordsMap.get("id"), insertRecordsMap.get("firstname"),
	 * insertRecordsMap.get("lastname"), insertRecordsMap.get("cdate") };
	 */
	 
	 
	
			
	
	  public int insertLOSRecords(String Query,Object[] params) throws Exception{ 
		  long start_time = System.currentTimeMillis(); 
		  int rowinserted = 0;
		  try {
		  rowinserted = jdbcTemplate2.update(Query, params);		  
		} catch (Exception e) {
			logger.error("Error while inserting records into database caused by--->", e);
			throw new Exception("Invalid Record "+e.getCause());
		}finally {
			  logger.info(rowinserted + " Row inserted Successfully");
			  long end_time = System.currentTimeMillis();
			  logger.info("Time taken to insert the record in database is --->" + (end_time - start_time));
		}
		return rowinserted;
	}
}
