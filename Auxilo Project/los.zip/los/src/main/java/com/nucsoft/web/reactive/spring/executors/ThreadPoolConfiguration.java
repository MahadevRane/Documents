package com.nucsoft.web.reactive.spring.executors;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.nucsoft.web.reactive.spring.processor.RequestFactoryInitializer;



@Configuration
public class ThreadPoolConfiguration {
	
	@Value(value="${corePoolSize}")
	int corePoolSize;
	
	@Value(value="${maxPoolSize}")
	int maxPoolSize;
	
	@Value(value="${keepAliveTime}")
	int keepAliveTime;
	
	@Bean("requestProcessor")
	public DefaultThreadPoolExecutor defaultThreadPoolExecutor() {
		return new DefaultThreadPoolExecutor(corePoolSize,maxPoolSize, keepAliveTime,blockingQueue(), "requestAcceptor");
	}


	@Bean("blockingQueue")
	public Queue<IServiceExecutor> blockingQueue() {
		return new LinkedBlockingQueue<>();
	}
	
	
	@Bean (name="threadPoolTaskExecutor")
	public DefaultThreadPoolTaskExecutor getDefaultThreadPoolTaskExecutor(){
		return new DefaultThreadPoolTaskExecutor(corePoolSize,maxPoolSize, keepAliveTime, "template"); 
	}
	
	@Bean (name="requestFactory")
	public RequestFactoryInitializer getRequestFactory(){
		return new RequestFactoryInitializer(getDefaultThreadPoolTaskExecutor()); 
	}



	
	
	
	
}
