package com.nucsoft.web.reactive.spring.beans;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class WebClientBeans {

	private Logger logger = Logger.getLogger(WebClientBeans.class);

	/*
	 * Here we are creating bean of web client builder.
	 */
	/*
	 * @Bean("webClientBean") public WebClient webClientBuilder(WebClient.Builder
	 * builder) { return builder.build(); }
	 */

	@Bean(name = "dspro1")
	@ConfigurationProperties("spring.datasource1")
	public DataSourceProperties dataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean(name = "pgDatasource1")
	@ConfigurationProperties(prefix = "spring.datasource1")
	public HikariDataSource dataSource(@Qualifier("dspro1") DataSourceProperties properties) {
		return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean(name = "pgJdbcTemplate1")
	public JdbcTemplate jdbcTemplate1(@Qualifier("pgDatasource1") DataSource ds) {
		return new JdbcTemplate(ds);
	}

	
	@Bean(name = "dspro2")
	@ConfigurationProperties("spring.datasource2")
	public DataSourceProperties dataSourceLOSProperties() {
		return new DataSourceProperties();
	}
	
	@Bean(name = "pgDatasource2")
	@ConfigurationProperties(prefix = "spring.datasource2")
	public HikariDataSource dataSourceLOS(@Qualifier("dspro2") DataSourceProperties properties) {
		return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean(name = "pgJdbcTemplate2")
	public JdbcTemplate jdbcTemplateLOS(@Qualifier("pgDatasource2") DataSource ds) {
		return new JdbcTemplate(ds);
	}
}
