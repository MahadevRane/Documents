package com.nucsoft.web.reactive.spring.executors;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.nucsoft.web.reactive.spring.handler.RejectHandler;


/**
 * <p>
 *    This class needs to be inititalized by the caller
 * </p>
 * @author Satish Belose
 *
 */
public class DefaultThreadPoolTaskExecutor extends ThreadPoolTaskExecutor {
              

       private Logger logger = Logger.getLogger(this.getClass());
       private String taskExecutorName;
       public DefaultThreadPoolTaskExecutor(int corePoolSize, int maximumPoolSize,int keepAliveTime,String executorName){
        super.setRejectedExecutionHandler(new RejectHandler());
        super.setCorePoolSize(corePoolSize);
        super.setMaxPoolSize(maximumPoolSize);
        super.setKeepAliveSeconds(keepAliveTime);
        this.taskExecutorName = executorName;
        super.setTaskDecorator(new TaskDecorator() {
        	public Runnable decorate(Runnable runnable) {
        		logger.info("Running custom thread pool executor "+ DefaultThreadPoolTaskExecutor.this.taskExecutorName + " with statistics " + DefaultThreadPoolTaskExecutor.this.getThreadPoolExecutor().toString());
        		return runnable;
        	}
        });
}

         @Override
         protected BlockingQueue<Runnable> createQueue(int queueCapacity) {
        	 return new LinkedBlockingQueue<Runnable>(queueCapacity) {
        		 private static final long serialVersionUID = 1L;

         @Override
         public boolean offer(Runnable e) {
        	 return false;
         		}
        	 };
         }

}
