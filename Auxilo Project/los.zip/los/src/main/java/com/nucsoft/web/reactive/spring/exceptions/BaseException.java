/**
 * 
 */
package com.nucsoft.web.reactive.spring.exceptions;

/**
 * @author Satish Belose
 *
 */
public class BaseException extends RuntimeException
{
 
		/**
		 * <p> 
		 *   Implementing default constructor
		 * </p>
		 */
		public BaseException(){
			super();
		}
		
		/**
		 * <p>
		 *    Create exception with custom message
		 * </p>
		 * @param message
		 */
		public BaseException(String message){
			super(message);
		}
		
		/**
		 * <p>
		 *   Create exception with custom message and throwable
		 * </p>
		 * @param message
		 * @param e
		 */
		public BaseException(String message,Throwable e){
			super(message,e);
		}
		
		/**
		 * <p> 
		 *    Create exception wrapping the cause exception
		 * </p>
		 * @param e
		 */
		public BaseException(Throwable e){
			super(e);
		}

}
