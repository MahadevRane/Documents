/**
 * 
 */
package com.nucsoft.web.reactive.spring.constant;

/**
 * @author Satish Belose
 *
 */
public interface Constants {
	
	String SERVICE_SOURCE_URL = "sourceurl";
	long DEFERRED_RESULT_TIMEOUT = 90000;
	
	String AUTHORIZATION_HEADER = "Authorization";
	String CONTENT_TYPE = "Content-Type";
	String TARGET_HEADERS = "targetheaders";
	//String CONSTANT_QUERY = "select * from constants";
	String USERNAME = "userName";
	String READ_TIMEOUT = "readtimeout";
	String CONNECTION_TIMEOUT = "connectiontimeout";
	String FACTORY_NAME = "requestFactory";
	String REQUEST_ACCEPTOR_TPE = "requestProcessor";
	String ERROR_ON_SERVICE_CALL = "{\"message\":\"Error while calling service,Please try agian after some time.\"}";
	
	String SERVICE_QUERY = "query";
	String SERVICE_QUERY_PARAM = "queryparam";

	
}
