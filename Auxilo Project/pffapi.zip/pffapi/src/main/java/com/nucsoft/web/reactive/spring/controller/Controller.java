/**
 * 
 */
package com.nucsoft.web.reactive.spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;

import com.nucsoft.web.reactive.spring.services.WebClientService;

/**
 * @author Satish Belose
 *
 */
@RestController
@RequestMapping("/pffapi/api/v1")
public class Controller {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private WebClientService webClientService;
	
	@PostMapping(value ="/{pathVariable}",consumes="application/json",produces="application/json")
	public @ResponseBody DeferredResult<Object> requestHandler(@RequestBody String requestBody,HttpServletRequest request,@PathVariable String pathVariable){
		
		logger.info("Request received in Controller --->"+requestBody);		
		return webClientService.requestProcessor(requestBody,request,pathVariable);
	}
	
	@GetMapping(value ="/test")
	public @ResponseBody DeferredResult<Object> requestHandler1(HttpServletRequest request){
		System.out.println("=====>>>>>");
		return webClientService.requestProcessor();
	}

}
