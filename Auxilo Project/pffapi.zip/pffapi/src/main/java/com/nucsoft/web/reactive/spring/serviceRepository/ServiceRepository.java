/**
 * 
 */
package com.nucsoft.web.reactive.spring.serviceRepository;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;


/**
 * @author Satish Belose
 *
 */
@Component
public class ServiceRepository {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	@Qualifier("pgJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Value("${apiname}")
	private String apiname;
	
	public Map<String,Map<String,String>> fetchConstantMap() {
		long start_time = System.currentTimeMillis();
		String uery = "select * from kong."+apiname+"_constants";
		logger.info("Query---->"+uery);
		System.out.println("Query---->"+uery);
		Map<String,Map<String,String>> constantsMap = new HashMap<>();	
		
		PreparedStatementCreator statementCreator = new PreparedStatementCreator() {
			   @Override
			   public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			       PreparedStatement ps = con.prepareStatement(uery);
			       ps.setObject(0, "");
			       return ps;
			   }
			};
			
			jdbcTemplate.query(statementCreator,new RowMapper() {

				@Override
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
					// TODO Auto-generated method stub
					String entityType = rs.getString("servicetype");
					System.out.println("entityType---"+entityType);
					if(!"".equals(entityType) && !constantsMap.containsKey(entityType)) {
						Map<String, String> temp = new HashMap<String, String>();
						temp.put(rs.getString("key"), rs.getString("value"));
						constantsMap.put(entityType, temp);
					}else {
						constantsMap.get(entityType).put(rs.getString("key"), rs.getString("value"));
					}
					return null;
				}
			});
		
		long end_time = System.currentTimeMillis();
		logger.info("Time taken to fetch the constant values from database is --->"+(end_time-start_time));
		return constantsMap;
	}
	
	public int insertRecords(Map<String,Object> insertRecordsMap) {
		long start_time = System.currentTimeMillis();	
		int rowinserted = 0;
		String uery = "insert into "+apiname+"_servicelog (requestdata,responsedata,updatedtime,createdtime,username,clientid,servicetype) values(?,?,?,?,?,?,?)";
		logger.info(insertRecordsMap);		
		try {
			Object[] params = new Object[] {insertRecordsMap.get("requestdata"),insertRecordsMap.get("responsedata"),insertRecordsMap.get("updatedtime"),
					insertRecordsMap.get("createdtime"),insertRecordsMap.get("username"),insertRecordsMap.get("clientid"),insertRecordsMap.get("servicetype")};
			rowinserted = jdbcTemplate.update(uery, params);
			logger.info(rowinserted+" Row inserted Successfully");
			long end_time = System.currentTimeMillis();
			logger.info("Time taken to insert the record in database is --->"+(end_time-start_time));
		}catch(Exception e) {
			logger.error("Error while inserting records into database caused by--->",e);
		}		
		return rowinserted;
	}
}
