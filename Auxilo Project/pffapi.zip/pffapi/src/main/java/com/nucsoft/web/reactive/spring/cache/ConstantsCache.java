package com.nucsoft.web.reactive.spring.cache;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.nucsoft.web.reactive.spring.serviceRepository.ServiceRepository;





/**
 * <p>
 *    Store the details of all external services 
 *    in cache
 * </p>
 * @author Satish Belose
 *
 */
@Component
public class ConstantsCache implements IServiceCache<Map<String,String>>,ApplicationContextAware
{  
	// store the application context
	private ApplicationContext context;
	
	private Map<String,Map<String,String>> dataMap = null;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Value(value="${cacheRefreshTimeMin}")
	String minutes;

	@Override
	public Map<String,Map<String,String>> getData() {
		// TODO Auto-generated method stub
		return dataMap;
	}

	@Override
	public long cacheRefreshTime() {	
		long refreshTime = -1l;		
		try {			
			long configTime = Long.parseLong(minutes);
			if(configTime > 0){
				refreshTime = configTime*60*1000;
			}	
		} catch (Exception e) {			
		}		
		return refreshTime;
	}

	@Override
	public void refreshData() {
		
		dataMap = context.getBean(ServiceRepository.class).fetchConstantMap();
		
	}
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.context = applicationContext;
		
	}

}
