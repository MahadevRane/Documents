package com.nucsoft.web.reactive.spring.executors;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.nucsoft.web.reactive.spring.processor.RequestFactoryInitializer;
import com.nucsoft.web.reactive.spring.properties.ReadProperties;



@Configuration
public class ThreadPoolConfiguration {

	ReadProperties environment = new ReadProperties();
	
	@Bean("requestProcessor")
	public DefaultThreadPoolExecutor defaultThreadPoolExecutor() {
		return new DefaultThreadPoolExecutor(Integer.parseInt(environment.getProperty("corePoolSize")),
				Integer.parseInt(environment.getProperty("maxPoolSize")),
				Integer.parseInt(environment.getProperty("keepAliveTime")),
				blockingQueue(), "requestAcceptor");
	}


	@Bean("blockingQueue")
	public Queue<IServiceExecutor> blockingQueue() {
		return new LinkedBlockingQueue<>();
	}
	
	
	@Bean (name="threadPoolTaskExecutor")
	public DefaultThreadPoolTaskExecutor getDefaultThreadPoolTaskExecutor(){
		return new DefaultThreadPoolTaskExecutor(Integer.parseInt(environment.getProperty("corePoolSize")),
				Integer.parseInt(environment.getProperty("maxPoolSize")),
				Integer.parseInt(environment.getProperty("keepAliveTime")), "template"); 
	}
	
	@Bean (name="requestFactory")
	public RequestFactoryInitializer getRequestFactory(){
		return new RequestFactoryInitializer(getDefaultThreadPoolTaskExecutor()); 
	}



	
	
	
	
}
